<a href="/admin">
    <div class=" ml-3 login flex p-1 hover:cursor-pointer bg-maroon hover:bg-darkcream rounded-md hidden md:block">
        <p class="text-light font-comfortaa">dashboard</p>
    </div>
    <div class=" ml-3 login flex justify-center p-1 hover:cursor-pointer bg-maroon hover:bg-darkcream rounded-md block md:hidden">
        <x-fas-gear class="h-6 w-6 text-light" />
    </div>
</a>