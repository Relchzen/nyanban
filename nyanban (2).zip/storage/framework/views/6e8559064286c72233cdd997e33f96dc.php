

<?php $__env->startSection('content'); ?>
    <?php if($editing ?? false): ?>
    <div class="container bg-light pt-4 pl-4 pr-4 pb-12 font-roboto">
        <p class="font-comfortaa font-semibold text-3xl mb-4">Create Menu</p>
        <form action="<?php echo e(route('menu.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="mb-4 grid grid-cols-8">              
                <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6 col-span-full">
                    <div class="md:col-span-4">
                        <label for="picture" class="block text-sm font-medium leading-6 text-gray-900">Menu Photo</label>
                        <div class="mt-2">
                        <input type="file" name="picture" id="picture" class="block w-full rounded-md border-0 py-1.5 px-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </div>
                    </div>
                    <div class="md:col-span-4">
                        <label for="menu_name" class="block text-sm font-medium leading-6 text-gray-900">Menu Name</label>
                        <div class="mt-2">
                        <input type="text" name="menu_name" id="menu_name" class="block w-full rounded-md border-0 py-1.5 px-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </div>
                    </div>
                    <div class="md:col-span-3">
                        <label for="price" class="block text-sm font-medium leading-6 text-gray-900">Price</label>
                        <div class="relative rounded-md shadow-sm">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <span class="text-gray-500 sm:text-sm">Rp</span>
                            </div>
                            <input type="number" name="price" id="price" class="block w-full rounded-md border-0 py-1.5 pl-12 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>

                    <div class="md:col-span-2">
                        <label for="category" class="block text-sm font-medium leading-6 text-gray-900">Category</label>
                        <div class="mt-2">
                          <select id="category" name="category" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:max-w-xs sm:text-sm sm:leading-6">
                            <option>Select a category</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ctgr->category); ?>"><?php echo e($ctgr->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    <div class="md:col-span-4 mt-6">
                        <label for="description" class="block text-sm font-medium leading-6 text-gray-900">Description</label>
                        <div class="mb-6 relative">
                            <textarea id="description" name="description" rows="3" class="block w-full rounded-md border-0 py-1.5 px-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"></textarea>
                        </div>
                    </div>  
                </div>
            </div>
            <button type="submit" class="flex flex-none justify-center bg-teal p-2 hover:bg-jade hover:text-light rounded-lg">Add Menu</button>             
            </form>
    </div>



    <?php else: ?>



    <div class="container bg-light pt-4 pl-4 pr-4 pb-12 font-roboto">
        <p class="font-comfortaa font-semibold text-3xl mb-4">Edit Menu</p>
        <form action="<?php echo e(route('menu.update', $menu->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="mb-4 grid grid-cols-8">              
                <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6 col-span-full">
                    <div class="md:col-span-4">
                        <label for="picture" class="block text-sm font-medium leading-6 text-gray-900">Menu Photo</label>
                        <div  class="w-3/5 aspect-square p-4 shadow rounded-lg mb-3">
                            <img src="<?php echo e($menu->getImageURL()); ?>" alt="" class="rounded-md">
                        </div>

                        <div class="mt-2">
                        <input type="file" name="picture" id="picture" class="block w-full rounded-md border-0 py-1.5 px-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" value="<?php echo e($menu->picture); ?>">
                        </div>
                    </div>
                    <div class="md:col-span-4">
                        <label for="menu_name" class="block text-sm font-medium leading-6 text-gray-900">Menu Name</label>
                        <div class="mt-2">
                        <input type="text" name="menu_name" id="menu_name" class="block w-full rounded-md border-0 py-1.5 px-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" value="<?php echo e($menu->menu_name); ?>">
                        </div>
                    </div>
                    <div class="md:col-span-3">
                        <label for="price" class="block text-sm font-medium leading-6 text-gray-900">Price</label>
                        <div class="relative rounded-md shadow-sm">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <span class="text-gray-500 sm:text-sm">Rp</span>
                            </div>
                            <input type="number" name="price" id="price" class="block w-full rounded-md border-0 py-1.5 pl-12 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" value="<?php echo e($menu->price); ?>"/>
                        </div>
                    </div>

                    <div class="md:col-span-2">
                        <label for="category" class="block text-sm font-medium leading-6 text-gray-900">Category</label>
                        <div class="mt-2">
                          <select id="category" name="category" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:max-w-xs sm:text-sm sm:leading-6">
                            <option disabled>Select a category</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($ctgr->category == $menu->category): ?>
                            <option value="<?php echo e($ctgr->category); ?>" selected><?php echo e($ctgr->category); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($ctgr->category); ?>"><?php echo e($ctgr->category); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    <div class="md:col-span-4 mt-6">
                        <label for="description" class="block text-sm font-medium leading-6 text-gray-900">Description</label>
                        <div class="mb-6 relative">
                            <textarea id="description" name="description" rows="3" class="block w-full rounded-md border-0 py-1.5 px-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"><?php echo e($menu->description); ?></textarea>
                        </div>
                    </div>  
                </div>
            </div>
            <button type="submit" class="flex flex-none justify-center bg-teal py-2 px-4 hover:bg-jade hover:text-light rounded-lg">Save</button>             
            </form>
    </div>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/admin/menu/detail.blade.php ENDPATH**/ ?>