

<?php $__env->startSection('content'); ?>
<div class="container bg-light p-4">
    <p class="font-comfortaa font-semibold text-3xl">Users</p>

    <div class="my-4">
        <a href="<?php echo e(route('user.create')); ?>" class="p-2 font-comfortaa text-lg rounded-lg hover:text-light bg-jade">
            Create User
        </a>
    </div>
    <div>
        <table class="w-full table-auto">
            <tr>
                <th>
                    First Name
                </th>
                <th>
                    Last Name
                </th>
                <th>
                    Email
                </th>
                <th>
                    Username
                </th>
                <th>
                    Gender
                </th>
                <th>
                    Birthdate
                </th>
                <th>
                    Admin
                </th>
                <th>
                    Action
                </th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td><?php echo e($user->first_name); ?></td>
                <td><?php echo e($user->last_name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->username); ?></td>
                <td><?php echo e($user->gender); ?></td>
                <td><?php echo e($user->birthdate); ?></td>
                <td><?php echo e($user->is_admin); ?></td>
                <td>
                    <div>
                        <a href="<?php echo e(route('user.edit', $user->id)); ?>">
                            Edit
                        </a>
                        <button onclick="toggleDeleteModal(<?php echo e($user->id); ?>)">
                            delete
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($users->links()); ?>

    </div>
</div>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="modal-container-<?php echo e($user->id); ?>" class="fixed invisible z-50 w-full h-full inset-0">
        <div id="modal-background-<?php echo e($user->id); ?>" onclick="toggleDeleteModal(<?php echo e($user->id); ?>)" class="absolute w-full h-full fixed bg-gray-900 opacity-0 duration-100 ease-out transition-all">
        </div>
        <div id="modal-<?php echo e($user->id); ?>" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-light h-min w-72 duration-200 ease-out transition-all rounded-lg scale-0">
            <div id="modal-header" class="m-4 text-xl font-comfortaa">
                Warning
            </div>
            <div id="modal-body" class="p-4 text-md font-comfortaa">
                Are you sure you want to delete "<?php echo e($user->first_name . ' ' . $user->last_name); ?>"?
            </div>
            <div class="flex justify-around p-4">
                <form action="<?php echo e(route('user.delete', $user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="bg-maroon p-2 rounded-md font-comfortaa text-light">
                        Yes, Delete
                    </button>
                </form>
                <button class="p-2 bg-gray-700 rounded-md font-comfortaa text-light" onclick="toggleDeleteModal(<?php echo e($user->id); ?>)">
                    No, Cancel
                </button>
            </div>
        </div>
    </div>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script type="text/javascript">
    function toggleDeleteModal(id) {
        document.getElementById("modal-container-"+id).classList.toggle("invisible");
        document.getElementById("modal-background-"+id).classList.toggle("opacity-0");
        document.getElementById("modal-background-"+id).classList.toggle("opacity-50");
        document.getElementById("modal-"+id).classList.toggle("scale-0");
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/admin/users.blade.php ENDPATH**/ ?>