

<?php $__env->startSection('navbar'); ?>
    <div>
        Navbar
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/layout/navbar.blade.php ENDPATH**/ ?>