

<?php $__env->startSection('content'); ?>
<div class="container bg-light p-4">
    <p class="font-comfortaa font-semibold text-3xl mb-4">Category</p>
    <div class="m-4">
        <p class="font-comfortaa text-lg mb-4">Add Category</p>
        <form action="<?php echo e(route('category.create')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="flex">
                <input type="text" class="rounded-lg w-64 p-2 font-roboto outline outline-offset-0 outline-1 outline-darkcream mr-3" name="inputCategory" id="inputCategory" placeholder="Add a new category" />
                <button class="bg-teal text-white p-2 rounded-lg" type="submit">Add</button>
            </div>
        </form>
    </div>
    <div class="m-4 relative w-96 overflow-x-auto rounded-md shadow">
        <table class="text-left text-lg font-roboto table-auto table-auto w-96">
            <thead class="border border-2 font-medium border-neutral-500">
                <tr>
                    <th scope="col" class="border border-2 w-3/5 p-2 border-dark">Category</th>
                    <th scope="col" class="border border-2 p-2 border-dark">Action</th>
                </tr>
            </thead>
            <tbody class="border border-2 border-neutral-500">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border w-3/5 border-2 p-2 border-dark">
                            <?php echo e($ctgr->category); ?>

                        </td>
                        <td class="border border-2 p-2 border-dark text-center">
                            <div class="flex">
                                <button onclick="toggleSlideOver()" class="hover:cursor-pointer rounded-md py-1 px-2 ml-2 bg-jade text-teal hover:text-light">Edit</button>
                                <form action="<?php echo e(route("category.destroy", $ctgr->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="hover:cursor-pointer rounded-md p-1 mx-2 bg-lightmaroon text-dark hover:text-light">Delete</button>
                                </form>
                            </div>
                            </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div id="slideover-container" class="fixed inset-0 w-full h-full invisible">
            <div id="slideover-bg" onclick="toggleSlideOver()" class="absolute duration-200 ease-out transition-all inset-0 w-full h-full bg-gray-900 opacity-0"></div>
            <div id="slideover" class="absolute duration-200 ease-out transition-all bg-light bottom-0 h-3/5 lg:h-2/5 w-full translate-y-full">
                <div onclick="toggleSlideOver()" class="w-8 h-8 flex items-center justify-center absolute top-0 right-0 mt-5 mr-5">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('lucide-x'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-dark']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

        <script>
            function toggleSlideOver() {
                

                document.getElementById("slideover-container").classList.toggle("invisible");
                document.getElementById("slideover-bg").classList.toggle("opacity-0");
                document.getElementById("slideover-bg").classList.toggle("opacity-50");
                document.getElementById("slideover").classList.toggle("translate-y-full");
            }
        </script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/admin/category.blade.php ENDPATH**/ ?>