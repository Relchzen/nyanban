        <!-- Repeat this product card for each product -->
        <div id="menu-card" onclick="toggleSlideOver(<?php echo e($menuId); ?>)" data-id="<?php echo e($menuId); ?>" class="rounded-lg bg-maroon hover:cursor-pointer hover:bg-lightmaroon transition ease-in-out duration-100">
            <div>
                <div class="flex overflow-hidden relative p-2">
                    <div class="rounded-lg">
                        <img src="<?php echo e($image); ?>" alt="Product Image" class="object-cover aspect-square rounded-lg">
                    </div>
                </div>
                <div class="mx-4 mb-2 flex flex-col">
                    <p class="text-light text-sm font-comfortaa"><?php echo e($name); ?></p>
                </div>
            </div>
        </div>

        <div id="slideover-container<?php echo e($menuId); ?>" class="fixed inset-0 w-full h-full invisible z-30">
            <div id="slideover-bg<?php echo e($menuId); ?>" onclick="toggleSlideOver(<?php echo e($menuId); ?>)" class="absolute duration-200 ease-out transition-all inset-0 w-full h-full bg-gray-900 opacity-0"></div>
            <div id="slideover<?php echo e($menuId); ?>" class="p-5 absolute duration-200 ease-out transition-all bg-light bottom-0 h-3/4 lg:h-2/4 w-full translate-y-full">
                <div onclick="toggleSlideOver(<?php echo e($menuId); ?>)" class="w-8 h-8 flex items-center justify-center absolute top-0 right-0 mt-5 mr-5">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('lucide-x'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-dark']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </div>
                <div class="container flex justify-center mx-auto">
                    <div class="md:flex md:mr-5 md:mb-5 mr-0 mb-5">
                        <div class="w-64 h-64 mx-auto rounded-lg">
                            <img src="<?php echo e($image); ?>" class="object-cover rounded-lg aspect-square" alt="<?php echo e($name); ?>">
                        </div>
                        <div class="md:ml-5 md:mt-0 ml-0 mt-5">
                            <div class="text-3xl mb-1 font-comfortaa font-semibold text-dark"><?php echo e($name); ?></div>
                            <div class="text-xl font-comfortaa text-dark">Rp <?php echo e(number_format($price, 0, '.')); ?></div>
                            <div class="text-md font-roboto text-dark max-w-xl"><?php echo e($desc); ?></div>
                            
                            <?php if(auth()->user()): ?>
                            <div>
                                <button class="p-2 font-comfortaa flex justify-center rounded-3xl bg-jade">Add</button>
                            </div>
                            <?php if(auth()->user()->is_admin): ?>
                            <div class="flex justify-end">
                                <a href="<?php echo e(route('menu.edit', $menuId)); ?>" class="m-2 p-1 font-comfortaa bg-jade w-16 flex justify-center rounded-md">Edit</a>
                                <button onclick="toggleDeleteModal(<?php echo e($menuId); ?>)" class="m-2 p-1 font-comfortaa bg-lightmaroon w-16 flex justify-center rounded-md">Delete</button>
                            </div>
                            <?php endif; ?>
                            <?php else: ?>
                            <div class="flex justify-end">
                                <a href="/login" class="p-2 font-comfortaa flex justify-center rounded-3xl bg-jade">
                                    Add
                                </a>

                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="modal-container-<?php echo e($menuId); ?>" class="fixed invisible z-50 w-full h-full inset-0">
            <div id="modal-background-<?php echo e($menuId); ?>" onclick="toggleDeleteModal(<?php echo e($menuId); ?>)" class="absolute w-full h-full fixed bg-gray-900 opacity-0 duration-100 ease-out transition-all">
            </div>
            <div id="modal-<?php echo e($menuId); ?>" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-light h-min w-72 duration-200 ease-out transition-all rounded-lg scale-0">
                <div id="modal-header" class="m-4 text-xl font-comfortaa">
                    Warning
                </div>
                <div id="modal-body" class="p-4 text-md font-comfortaa">
                    Are you sure you want to delete "<?php echo e($name); ?>"?
                </div>
                <div class="flex justify-around p-4">
                    <form action="<?php echo e(route('menu.delete', $menuId)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="bg-maroon p-2 rounded-md font-comfortaa text-light">
                            Yes, Delete
                        </button>
                    </form>
                    <button class="p-2 bg-gray-700 rounded-md font-comfortaa text-light" onclick="toggleDeleteModal(<?php echo e($menuId); ?>)">
                        No, Cancel
                    </button>
                </div>
            </div>
        </div>

        <!-- End of product card --><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/components/menu.blade.php ENDPATH**/ ?>