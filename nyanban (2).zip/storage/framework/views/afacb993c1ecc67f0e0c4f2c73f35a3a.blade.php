<svg class="h-6 w-6 mr-2 text-white hover:text-underline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8.9 7.56c.31-3.6 2.16-5.07 6.21-5.07h.13c4.47 0 6.26 1.79 6.26 6.26v6.52c0 4.47-1.79 6.26-6.26 6.26h-.13c-4.02 0-5.87-1.45-6.2-4.99M2 12h12.88"/>
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12.65 8.65L16 12l-3.35 3.35"/>
</svg>