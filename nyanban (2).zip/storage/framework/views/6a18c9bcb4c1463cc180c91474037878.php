

<?php $__env->startSection('content'); ?>
<div class="container bg-light p-4">
    <p class="font-comfortaa font-semibold text-3xl mb-4">Menu</p>
    <div class="mb-4">
        <a href="/admin/menu/create" class="font-comfortaa p-2 rounded-md hover:bg-jade hover:text-dark text-lg mb-4 font-semibold bg-teal text-light">Create Menu</a>
    </div>
    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4">
                <div>
                    <p class="font-comfortaa text-3xl text-dark m-2"><?php echo e($cat->category); ?></p>
                </div>
                <div class="grid grid-cols-2 lg:grid-cols-6 gap-3">
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($mn->category == $cat->category): ?>
                            <?php if (isset($component)) { $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve(['menuId' => ''.e($mn->id).'','name' => ''.e($mn->menu_name).'','image' => ''.e($mn->getImageURL()).'','desc' => ''.e($mn->description).'','price' => ''.e($mn->price).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $component = $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>                    
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    function toggleSlideOver(id) {
        document.getElementById("slideover-container"+id).classList.toggle("invisible");
        document.getElementById("slideover-bg"+id).classList.toggle("opacity-0");
        document.getElementById("slideover-bg"+id).classList.toggle("opacity-50");
        document.getElementById("slideover"+id).classList.toggle("translate-y-full");
    }

    function toggleDeleteModal(id) {
        document.getElementById("modal-container-"+id).classList.toggle("invisible");
        document.getElementById("modal-background-"+id).classList.toggle("opacity-0");
        document.getElementById("modal-background-"+id).classList.toggle("opacity-50");
        document.getElementById("modal-"+id).classList.toggle("scale-0");
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/admin/menu.blade.php ENDPATH**/ ?>