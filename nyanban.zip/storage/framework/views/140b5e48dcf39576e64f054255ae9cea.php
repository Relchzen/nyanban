<?php $__env->startSection('content'); ?>
    <div class="container px-28 bg-cream mx-auto">
        Profile
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/profile.blade.php ENDPATH**/ ?>