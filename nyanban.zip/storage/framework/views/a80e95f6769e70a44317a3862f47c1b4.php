

<?php $__env->startSection('content'); ?>

<div class="md:container mx-auto">
    Admin
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/admin.blade.php ENDPATH**/ ?>