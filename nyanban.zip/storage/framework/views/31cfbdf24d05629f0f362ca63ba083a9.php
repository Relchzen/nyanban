<a href='/profile' class="mt-2 md:mt-2 md:mb-2">
    <div class="font-comfortaa text-sm md:text-md hover:underline">
        Welcome, <?php echo e(Auth::user()->username); ?>

    </div>
</a><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/components/profile-button.blade.php ENDPATH**/ ?>