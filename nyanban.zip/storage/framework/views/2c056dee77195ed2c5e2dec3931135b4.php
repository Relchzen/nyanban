<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Nyanban - Login</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@400;600&display=swap" rel="stylesheet">
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
        <!-- Styles -->
    </head>
    <body class="antialiased bg-cream font-comfortaa">
       <div class="container mx-auto">
           <div class="grid h-screen content-start justify-items-center py-16 md:content-center">
                <div class="w-min">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <br><br>
                <div class="md:mb-48 bg-jade p-4 rounded-sm">
                    <p class="text-dark text-xl mb-2">Login</p>
                    <form action="/auth/login" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="email" id="email" class="mb-2 p-2 w-72 rounded-md" placeholder="Email address" autocomplete="off" />
                        <br />
                        <input type="password" name="password" id="password" class="mb-2 p-2 w-64 rounded-md" placeholder="Password" autocomplete="off" />
                        <br />
                        <button type="submit" class="text-center p-1 hover:text-light w-full bg-teal rounded-md my-2 scale-95 hover:scale-100 transition ease-in-out duration-100">Login</button>
                    </form>
                    <div class="flex mb-2">
                        <p class="text-dark text-sm mr-2">Don't have an account?</p>
                        <a class="text-sm text-maroon" href="/signup">Sign Up</a>
                    </div>
                </div>
            </div>            
        </div>

    </body>
</html>
<?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/login.blade.php ENDPATH**/ ?>