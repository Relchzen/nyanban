

<?php $__env->startSection('content'); ?>
<div class="container bg-light p-4">
    <p class="font-comfortaa font-semibold text-3xl mb-4">Menu</p>
    <div class="mb-4">
        <a href="/admin/menu/create" class="font-comfortaa p-2 rounded-md hover:bg-jade hover:text-dark text-lg mb-4 font-semibold bg-teal text-light">Create Menu</a>
    </div>
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve(['menuId' => ''.e($mn->id).'','name' => ''.e($mn->menu_name).'','image' => ''.e($mn->getImageURL()).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $component = $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div id="slideover-container" class="fixed inset-0 w-full h-full invisible">
    <div id="slideover-bg" onclick="toggleSlideOver()" class="absolute duration-200 ease-out transition-all inset-0 w-full h-full bg-gray-900 opacity-0"></div>
    <div id="slideover" class="absolute duration-200 ease-out transition-all bg-light bottom-0 h-3/5 lg:h-2/5 w-full translate-y-full">
        <div onclick="toggleSlideOver()" class="w-8 h-8 flex items-center justify-center absolute top-0 right-0 mt-5 mr-5">
            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('lucide-x'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-dark']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
        </div>
    </div>
</div>

<script>
    function toggleSlideOver() {
        document.getElementById("slideover-container").classList.toggle("invisible");
        document.getElementById("slideover-bg").classList.toggle("opacity-0");
        document.getElementById("slideover-bg").classList.toggle("opacity-50");
        document.getElementById("slideover").classList.toggle("translate-y-full");
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\kuliah\webProgramming\nyanban\resources\views/admin/menu.blade.php ENDPATH**/ ?>