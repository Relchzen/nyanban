@extends('layout.layout')

@section('content')
    <div class="container px-28 bg-cream mx-auto">
        Profile
    </div>
@endsection