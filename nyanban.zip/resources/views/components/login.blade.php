
<a href="/login">
    <div class="login flex p-1 hover:cursor-pointer bg-cream hover:bg-darkcream rounded-md">
        <x-iconsax-lin-login class="h-6 w-6 mr-2 text-dark" />
        <p class="text-lg text-dark font-comfortaa">Login</p>
</div>
</a>