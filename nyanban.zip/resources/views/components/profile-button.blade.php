<a href='/profile' class="mt-2 md:mt-2 md:mb-2">
    <div class="font-comfortaa text-sm md:text-md hover:underline">
        Welcome, {{ Auth::user()->username }}
    </div>
</a>