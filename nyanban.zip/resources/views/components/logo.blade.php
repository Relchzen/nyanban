<a href="/" class="flex-none">
<div class="flex p-1 hover:cursor-pointer">
    <x-lucide-cat class="w-7 h-7 text-dark mb-1" />
        <p class="text-dark text-2xl font-comfortaa font-semibold">
            Nyanban
        </p>
    </div>
</a>