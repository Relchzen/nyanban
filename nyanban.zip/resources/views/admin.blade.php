@extends('layout.admin')

@section('content')

<div class="md:container mx-auto">
    Admin
</div>

@endsection